# 拆文与证据

先确认分析范围。链接可用于查证，但网页预览不是全书。没有完整文本就只分析可见部分，标明缺章、取样方式和来源日期；不虚构剧情。保留番外、序章和特殊标题。此流程产物只作参考资料，不进入原创书的事实卡。

## 建立可恢复语料

续跑先看 `status.recent_sources` 的 source、next_chunk 和 report_path；更多来源用 `sources` 分页查找。已有来源直接 next，不重新 ingest。全部块完成且还没有 report_path 时从聚合继续。

`init --book "<独立分析目录>" --title "<作品>" --kind analysis`。

`ingest --book "<目录>" --file "<原文.txt>" --coverage complete|partial|unknown` 保存不可变文本和来源哈希，按章节标题/字符上限切块；默认 coverage 为 unknown。支持 UTF-8，其他编码显式 `--encoding gb18030`。切块是工程边界，不能据此声称章节目录完整；用 `coverage --source ID` 与真实目录核对。无标题的文本同样可以分析，不凭空编号章节。

`next --source ID --limit 2 --budget-bytes 22000` 只返回未分析块，带原文范围与哈希；文本太大时明确报预算不足。块在语义中间切开时用 `source-read --source ID --start A --end B` 读取相邻证据。不得用不存在的上下文补因果。

纯空白块自动记为 `non_content`，保留原范围与哈希，不算语义分析；旧断点在 next 时同样恢复，已有分析不覆盖。

## 逐块积累

`template analysis` 给出结构。每块记：关键事件和选择、可证实的因果、情绪变化、有效/无效写法；每条 finding 包含 claim、kind 与精确 quote。短小完整句足够，不把原文复制成报告。用 `record --source ID --chunk K --input "<结果.json>"` 原子保存，哈希或引用不符会拒绝。相同结果重交幂等，已完成块不重跑。需要修订分析时显式 `--replace`，保留旧版本事件记录。

开篇点评只处理相关块并输出范围明确的预览；用户要求全量时循环 next/record 到覆盖完成，不再停在预览处确认。token 预算只控制一次读取，不缩减用户要求的总覆盖。

## 聚合与交付

`coverage` 检查块数、漏块和原文覆盖标签。`findings --source ID --offset 0 --limit 10 --budget-bytes 20000` 分页读已保存的紧凑结果；大量结果先按剧情单元在分析目录下生成带 chunk id 的小结，再合并小结，保留证据 id，不重读全书。

报告按实际作品组织：开篇吸引力、人物欲望与关系、冲突/升级/反转因果、情绪与节奏、文风、失效场景、可迁移方法及不能照搬的具体表达。每个重要结论指向块号和短引文；事实、解释和建议分开。篇幅服从证据量，不为凑模板创建空文件。

`report --source ID --file "<报告.md>"` 仅在所有导入块均已分析时接受最终报告，并导出 `.story/analysis/ID/report.md`。工具会注明 complete/partial/unknown；“所导入块全部完成”不等于“全书无遗漏”。阶段性预览直接另存 preview.md，不冒充最终报告。
